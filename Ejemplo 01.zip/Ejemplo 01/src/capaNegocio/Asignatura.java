package capaNegocio;

public class Asignatura {

    public Asignatura() {
        this.nombre = "";
        this.creditos = 0;
        this.horas = 0;
        this.codigo = "";
    }

    public Asignatura(String nombre, int creditos, int horas, String codigo) {
        this.nombre = nombre;
        this.creditos = creditos;
        this.horas = horas;
        this.codigo = codigo;
    }
    
    
    
    private String nombre;
    private int creditos;
    private int horas;
    private String codigo;

    public Catalogo perteneceCatalogo;
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCreditos() {
        return creditos;
    }

    public void setCreditos(int creditos) {
        this.creditos = creditos;
    }

    public int getHoras() {
        return horas;
    }

    public void setHoras(int horas) {
        this.horas = horas;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    
    public String Aprobar()
    {
        return "Este metodo no esta disponible";
    }
    public String Desaprovar()
    {
        return "Este metodo no esta disponible";
    }
    public String Dispensar()
    {
        return "Este metodo no esta disponible";
    }
}

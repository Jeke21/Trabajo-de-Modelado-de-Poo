package capaNegocio;

import java.util.ArrayList;

public class Catalogo {
    
    //Contructor con inicializacion de variables
    public Catalogo() {
        this.cantidadAsignatura = "";
    }
    
    //Constructor sobrecargado de metodos
    public Catalogo(String cantidadAsignatura) {
        this.cantidadAsignatura = cantidadAsignatura;
    }
    
    //Atributos
    private String cantidadAsignatura;

    public Matricula etsaEnMatricula;
    public ArrayList <Asignatura> constaAsignaturas = new ArrayList();
    
    public String getCantidadAsignatura() {
        return cantidadAsignatura;
    }

    public void setCantidadAsignatura(String cantidadAsignatura) {
        this.cantidadAsignatura = cantidadAsignatura;
    }
    
    //Operaciones
    
    public String OfrecerAsignatura()
    {
        return "Este metodo no esta disponible";
    }
    
    public String DistribuirAsignaturas()
    {
        return "Este metodo no esta disponible";
    }
}

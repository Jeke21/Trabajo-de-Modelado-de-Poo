package capaNegocio;

import java.util.ArrayList;

public class Facultad {
    // Constructores
    public Facultad() {
        this.nombres = "";
        this.decano = "";
        this.ubicacion = "";
        this.codigo = "";
    }

    public Facultad(String nombres, String decano, String ubicacion, String codigo) {
        this.nombres = nombres;
        this.decano = decano;
        this.ubicacion = ubicacion;
        this.codigo = codigo;
    }
    
    //Atributos 
    private String nombres;
    private String decano;
    private String ubicacion;
    private String codigo;
    
    public ArrayList<EscuelaProfesional> tieneEscuelaProfesional = new ArrayList();

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getDecano() {
        return decano;
    }

    public void setDecano(String decano) {
        this.decano = decano;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }        
}


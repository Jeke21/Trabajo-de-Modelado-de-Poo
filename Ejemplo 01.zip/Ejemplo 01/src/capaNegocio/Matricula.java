package capaNegocio;

import java.util.ArrayList;

public class Matricula {
    
    //Contructor con inicializacion de variables
    public Matricula() {
        this.codAlumno = "";
        this.planEstudios = "";
        this.semestre = "";
    }
    
    //Constructor sobrecargado de metodos
    public Matricula(String codAlumno, String planEstudios, String semestre) {
        this.codAlumno = codAlumno;
        this.planEstudios = planEstudios;
        this.semestre = semestre;
    }
    
    //Atributos
    private String codAlumno;
    private String planEstudios;
    private String semestre;

    public ArrayList <Alumno> correspondeAlumno = new ArrayList();
    public ArrayList <Catalogo> tieneCatalogo = new ArrayList();
    
    public String getCodAlumno() {
        return codAlumno;
    }

    public void setCodAlumno(String codAlumno) {
        this.codAlumno = codAlumno;
    }

    public String getPlanEstudios() {
        return planEstudios;
    }

    public void setPlanEstudios(String planEstudios) {
        this.planEstudios = planEstudios;
    }

    public String getSemestre() {
        return semestre;
    }

    public void setSemestre(String semestre) {
        this.semestre = semestre;
    }
    
    //Operaciones
    
    public String Matricular()
    {
        return "Matricular no esta disponible";
    }
    
    public String Pagar()
    {
        return "Pagar no esta disponible";
    }
}

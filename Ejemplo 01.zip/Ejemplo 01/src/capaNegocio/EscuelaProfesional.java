
package capaNegocio;

import java.util.ArrayList;

public class EscuelaProfesional {
    // Constructores
    public EscuelaProfesional() {
        this.nombres = "";
        this.encargado = "";
        this.codigo = "";
    }

    public EscuelaProfesional(String nombres, String encargado, String codigo) {
        this.nombres = nombres;
        this.encargado = encargado;
        this.codigo = codigo;
    }
    
    // Atributos
    private String nombres;
    private String encargado;
    private String codigo;

    public Facultad perteneceFacultad;
    public ArrayList <Alumno> tieneAlumno = new ArrayList();
    
    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getEncargado() {
        return encargado;
    }

    public void setEncargado(String encargado) {
        this.encargado = encargado;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
}
